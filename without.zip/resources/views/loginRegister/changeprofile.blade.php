@extends('protien.master')
@section('head')
    <style>body{background: silver;color:whitesmoke;font-weight: bolder;font-size: 21px}</style>
@endsection
@section('mesg')

{{--    {{print_r(Session::all())}}--}}


    <div class="container">
    <div class="row">
        <div class="col-md-4">
            <br><br>
            <form action='{{url("user")}}/{{Auth::user()->id}}'  method="POST">
                 @csrf
                <input type="hidden" name="_method" value="PUT">
                <input class="form-control"  name="oldpassword" type="password" placeholder="type your old password">
                <input class="form-control"  name="newpassword1" type="password" placeholder="type your new password">
                <input class="form-control"  name="newpassword2"  type="password" placeholder="confirm your new password">
                <input class='form-control btn-danger' type='submit' value='CHANGE PASSWORD !'>
            </form>


            @if(! Auth::user()->img  )
                <form method="post" action="{{url('user')}}/{{auth()->id()}}" enctype="multipart/form-data">
                    @csrf
                    <input class='form-control' type='file' multiple="yes"  name='img[]'>
                    <input class='form-control btn-danger' type='submit' value='upload pic'>
                 </form>
            @endif
        </div>
    </div>
</div>

<hr>

@php
$all= \App\User::all();

@endphp





        <h1> @if($errors->has(1))  Passwords should not be empty  @endif </h1>
        <h1> @if($errors->has(2))  Passwords not quals  @endif</h1>
        <h1> @if($errors->has(3))  your current password not correct  @endif</h1>

@if(session()->has('password'))
    <b><center>
            <h1>{{session()->get('password')}}</h1>
    </center></b>
@endif

<hr>


{{$x}}

@stop()
