@extends('loginRegister.master')
@section('mesg')
<br>
<br>
<br>

    <div style="text-align: center; opacity:0.7">


            <div class="container">
                  <div style="width: 30%; height: 30%; margin:auto; margin-top: 200px">
                  <h2 class="container">Registeration Form</h2>

        <form class="form-group" method="post" action="/register" >
            {{csrf_field()}}
            <input class="form-control" value="{{old('name')}}"     type="text"     name="name"     placeholder="Your Name">
            <input class="form-control" value="{{old('email')}}"    type="text"    name="email"    placeholder="Your Eamil">
            <input class="form-control" value="{{old('password')}}" type="password" name="password" placeholder="Your Password">
            <input class="form-control btn btn-success" type="submit" name="submit" value="Register">
        </form>
    </div>
      </div>



    <div class="container"  style="background-image:url('/../mm.jpg') ">
        @foreach($errors->all() as $error   )
            <div style="font-size: 30px" class="font-weight-bold" style="color: #5a6268; font-size: large">
            {{ $error }}
        @endforeach
        </div>
    </div>


 </div>





@stop()
