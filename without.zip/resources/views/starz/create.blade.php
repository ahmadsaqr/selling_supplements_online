@extends('protien.master')
@section('mesg')
    <h3 style="text-align: center;text-decoration:underline #fd7e14">Create New Starz... </h3>

    <div class="container">
        <div style="text-align: center; opacity:0.7">

    {!! Form::open(['url' => 'ahmad/starz']) !!}
        {!! form::text('name', old('name'),['class'=>'form-control','placeholder'=>'type your name']) !!}
        {!! form::text('position', old('position'),['class'=>'form-control','placeholder'=>'type your job']) !!}
        {!! form::text('mobile', old('mobile'),['class'=>'form-control','placeholder'=>'type your mobile number']) !!}
        {!! form::submit('Register NEW STARZ',['class'=>'form-control']) !!}
    {!! Form::close() !!}


        </div>
    </div>
    <br>

    <div class="container"  style="background-image:url('/../mm.jpg') ">
    @foreach($errors->all() as $error)
        <div  class="font-weight-bold" style="color: #5a6268; font-size: large">{{ $error }}</div>
    @endforeach
    </div>

@endsection()