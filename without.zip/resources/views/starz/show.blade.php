
@extends('protien.master')
@section('mesg')
<h2 class="text-center">information of your starz... </h2><br>

    <h4 class="btn-outline-danger">Mr. {{$starz->name}} is awesome!  </h4><hr>
    <h4 class="btn-outline-success">His Mobile Number {{$starz->mobile}}   </h4><hr>
    <h4 class="btn-outline-secondary">His current position is {{$starz->position}}  </h4><hr>


@endsection()
