@extends('protien.master')

@section('mesg')



@include('protien.acor')<br>

@if($errors->has('double-comment'))
    <script >
        alert('You are only allowed of one comment');
    </script>
@endif


@if(session()->has('mesg'))
    <div style="text-align: center;" class="text-center btn btn-info" >
            {{session()->get('mesg') }}
    </div>
@endif





<div class="container">
    <div class="row">
        @foreach($all as $one)

            <div id="protienbox" class="col-sm-5 col-md-3  col-xl-2 ">

                <a style="display:inline-block" href="{{url('company')}}/{{$one->company->id}}">
                    @if($one->company->img)
                       <img class="img-company"
                            src="{{$one->company->name}}.{{$one->company->img}}">
                    @else
                        <img class="img-thumbnail img-responsive img-company"
                             src="{{url('com.png')}}">
                    @endif
                </a>

                <div class="price">
                    <b>
                        ${{$one->price}}
                    </b>
                </div>


              <div class="text-center" id="buynow">
                <a href="{{url('protien')}}/{{$one->id}}">
                    @if($one->img === 'fakeNull.jpg' || $one->img === '' )
                        <img class="x card-img"
                             style="width:130px;height:130px;display:block; margin:0 auto"
                             src="{{url('wow.png')}}">
                    @else
                        <img class="x card-img"
                             style="width:130px;height:130px;display:block;margin:0 auto"
                             src="{{url('uploaded')}}/{{$one->img}}" >
                    @endif
                </a>
                  <a href='{{url("buynow/".$one->id)}}' >Buy Now</a>
                  <br>

              </div>




      <div class="text-center">
          @if(Auth::user())
             @if(Auth::user()->admin === 1)


            <form style="display:inline" action="protien/{{$one->id}}" method="post">
                      @csrf
                      @method('DELETE')
                      <input type="checkbox" name="del[]" value="{{$one->id}}">
                      <span class="btn btn-danger" style="margin-bottom:15px !important;padding: 3px">
                      <input style="font-weight: bolder;margin-left: -5px;
                                  background-color: transparent; border-color: transparent" 
                                  type="submit"  value='Del'>

                      <i class="fas fa-trash fa-2x" style="margin-left:-8px"></i>
                      </span>
            </form>

                        <a class="admin" href="protien/{{$one->id}}/edit">
                            <i style="margin-bottom:15px !important" class="far fa-edit fa-2x btn btn-info"></i>
                        </a>
                    @endif
                @endif
                </div>
            </div>
        @endforeach
    </div>
</div>




@endsection()

@section('script')

@endsection



