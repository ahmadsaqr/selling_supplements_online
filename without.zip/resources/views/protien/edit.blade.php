@extends('protien.master')
@section('head')
    <style>
        body{background: black;
            color:white;
            font-weight: bolder;
            font-size: 21px}
    </style>
@endsection



@section('mesg')
    <BR>
    <h3 style="text-align: center">Update Info This Supplemnt... </h3>

    @php
        /*
            because the values are duplicated
            so if we get all of the by $protien->type
            and then try to put them as <option> then the items will be duplicated. So:
            we make loop in an empty array and after that we go the unique values
            ***----ALSO---***
            Please Note that we used $proteins only down function
            because it will loop all types and use them to get their values
            But for all <option> we used only $protien because we deal with one value !
         */

        foreach($protiens as $pro){
                $types[]=$pro->type;
                $uni    =array_unique($types);
            }
    $pro_type=['Isolated Whey Protein',
               'Fat Burner' ,
               'Whey Protein',
               'Mass Gainer',
               'BSAAs',
               'preWorkOut'];
    @endphp


    <div class="container">
        <div class="row">
            <div class="col-sm-3" style= "border-right:2px solid black">
                @if($protien->img === 'fakeNull.jpg'  || $protien->img=='')
                    <img class="img-fluid" style="width:245px" src="../../wow.jpg" alt="">
                @else
                    <img src="../../uploaded/{{$protien->img}}" style="width:245px" class="img-fluid" >
                @endif

                {{--<form class="form-control" action="/../../protien2/{{$protien->id}}" enctype="multipart/form-data" method="post">--}}
                    <form class="form-control" action="{{url('protien2')}}/{{$protien->id}}" enctype="multipart/form-data" method="post">
                        {{csrf_field()}}
                        @method('PUT')
                        <input class="form-group btn-block" type="file" name="img">
                        <input class="form-group btn-block btn-success" type="submit">
                    </form>
            </div>


            <div class="container col-lg-8" style="opacity: .8">
                    <form class="form-group" method="POST" action=" {{url('protien')}}/{{$protien->id}}  ">
                    @csrf
                    @method('PATCH')

                        <select  name='type' class="form-control">
                            @foreach($pro_type as $type)
                                <option @if($protien->type == $type)? selected  @endif  value="{{$type}}">
                                    {{$type}}
                                </option>
                            @endforeach
                        </select>


                        <select  name='company_id' class="form-control">
                            @foreach($company as $com)
                                <option @if ($protien->company->name == $com->name )? selected  @endif  value="{{$com->name}}">
                                    {{$com->name}}
                                </option>
                            @endforeach
                         </select>



                    <input value='{{$protien->price}}' class="form-control" type="text"  name="price" placeholder="Price of Your Supplemnts">
                    <input class="form-control btn btn-success" type="submit" value="Update your Supplemtns">
                </form>

                 @foreach($errors->all() as $one)
                    <div> {{$one}} </div>
                 @endforeach
        </div>
  </div>
</div>
@endsection()
