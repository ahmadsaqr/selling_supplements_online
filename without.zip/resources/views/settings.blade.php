@extends('protien.master')
@section('mesg')

@section('head')
    <style>
        body{background: black; color:white;font-weight: bolder;}
    </style>
@endsection

    @php
        $all= \App\Comment::all();
        $all_users= \App\User::all();

        $active=[];
        foreach ($all_users as $user){
            if($user->accept == 0){
                 $active[]=$user->accept;
            }
        }
    @endphp



<div class="container setting">
<div class="row">


    <div class="col-sm-12  col-md-6 offset-lg-2 col-lg-4 ">
         <form  action='{{url("settings")}}' method="post">
            @csrf()
             <h3 style="display: inline">Add Company</h3><br>
             <input type="text" name="name" placeholder="company"><br>
             <input type="submit" name="submit" value="Add Company">
         </form>
    </div>


    <div class="col-sm-12 col-md-6">
     <form action="{{url('settings')}}"  method="post">
         @csrf @method('DELETE')
         <h3 style="display: inline">Delete Company</h3><br>
            <select name="company">
                @foreach($com as $one)
                    <option value="{{$one->id}}">   {{$one->name}}-{{$one->id}}  </option>
                @endforeach
            </select>
         <br> <input type="submit" name="submit" value="Delete Company" >
     </form>
    </div>

    @foreach($errors->all() as $oneerror)
        <div class="btn btn-danger"> {{$oneerror}}   </div>
{{--        <script>alert({{$oneerror}}); </script>--}}
    @endforeach

</div>
</div>

    <table class="text-center col-sm-12 table-responsive" style="border: 10px red solid">
        <thead>
        <tr>
            <td>The Comments</td>
            <td>Custmor</td>
            <td>Protien Type</td>
            <td>Protien Picture</td>
            <td>Accpetance</td>
        </tr>
        </thead>



    @foreach($all as $one)
    @if($one->accept ==0)

    <tbody>
        <tr>
        <td>
           <form style="display:inline" action="{{url('editcomment')}}" method="post">
               @csrf
               @method('PUT')
               <input type="hidden" name="commentid" value="{{$one->id}}">
               <input type="hidden" name="protienid" value="{{$one->protien_id}}">
               <input type="text" name="commentbody" value={{$one->body}}>
               <input type="submit" class="btn btn-info" value="Edit">
           </form>
       </td>

       <td style="font-weight: bold">{{$one->custmor}}</td>

       <td> {{$one->company->name}} - {{$one->protien->type}}</td>

       <td>
           @if($one->protien->img !=='fakeNull.jpg')
                <img style="height:50px;width:50px;border-radius:50%" src="{{url('uploaded')}}/{{$one->protien->img}}">
            @else
                <img style="height:50px;width:50px;border-radius:50%"  src="{{url('wow.png')}}">
            @endif
       </td>

       <td>
           <form style="display:inline" action="{{url('acceptcomment')}}" method="post">
               {{csrf_field()}}
               <input type="hidden" name="_method" value="PUT">
               <input type="hidden" name="commentid" value="{{$one->id}}">
                   <input type="hidden" name="protienid" value="{{$one->protien_id}}">
               <input type="submit" class="btn btn-success" value="Accept">
           </form>

           <form style="display:inline" action="{{url('deletecomment')}}" method="post">
               {{csrf_field()}}
               <input type="hidden" name="_method" value="DELETE">
               <input type="hidden" name="custmor" value="{{$one->custmor}}">
               <input type="hidden" name="commentid" value="{{$one->id}}">
               <input type="submit" class="btn btn-danger" value="DELETE">
           </form>
       </td>

        @endif
        @endforeach
        </tr>
    </tbody>

</table>

<br><br><br>


     <table class="col-sm-12 text-center table table-bordered ">
         <tr>
                <td>Name</td>
                <td>Email</td>

{{--                  @if(!empty($active))--}}
                    <td>Membership Activation</td>
{{--                  @endif--}}

                <td>Upgrading</td>
                <td>Downgrading</td>
            </tr>

        @foreach($all_users as $user)
            <tr>
                <td>{{$user->name}}</td>
                <td>{{$user->email}}</td>

{{--                @if(!empty($active))--}}
                <td>
                    @if($user->accept === 0)
                    <form method="post" action="membership">
                        {{csrf_field()}}
                        <input type="hidden" name="user_id" value="{{$user->id}}">
                        <input name="accept" type="submit" value="accept">
                        <input name="reject" type="submit" value="reject">
                    </form>
                    @endif
                </td>
{{--                @ENDIF--}}



                <td>
                    @if($user->accept==1)
                        @if($user->admin ==1)
                                Admin
                        @else
                            <form method="post" action="upgrage">
                                @csrf
                                <input type="hidden" name="user_id" value="{{$user->id}}">
                                <input name="accept" type="submit" value="upGrade:)">
                            </form>
                        @endif
                    @else
                    @endif
                </td>


                <td>@if($user->accept==1 and $user->admin==1)
                        @if($user->email =='ahmadsaqr@hotmail.com')
                            SuperAdmin
                        @elseif($user->name==auth()->user()->name)
                            you cant delete yourSelf
                        @else
                            <form method="post" action="upgrage">
                                {{csrf_field()}}
                                <input type="hidden" name="user_id" value="{{$user->id}}">
                                <input type="submit" name="downgrage" value="downGrade">
                            </form>
                        @endif
                     @else
                     @endif
                </td>
            </tr>
        @endforeach
</table>






@endsection
