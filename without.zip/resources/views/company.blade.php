@extends('protien.master')
@section('head')
    <style>
        body{background:white;
            color:black;
            font-weight: bolder;
            font-size: 21px}
    </style>
@endsection
@section('mesg')
<div class="container">
    <br>

        <a href="{{url('company')}}" >
            <img class="img-thumbnail" style="width:200px;height:200px" src="../{{$company->name}}.{{$company->img}}" alt="">
        </a>

    <div class="clearfix">
        @if(Request::segment(2) < $last)

            <a href="{{url('company')}}/{{$last}}"><h6>NEXT COMPANY</h6></a>
            `
            @if(Request::segment(2) > 1)
                <a class="" href="{{url('company')}}/{{$previous}}"><h6>PREVIOUS COMPANY</h6></a>
            @endif

        @else
            <a class="" href="{{url('company')}}/{{$previous}}"><h6>PREVIOUS COMPANY</h6></a>
        @endif
    </div>


    <table class="table-striped table-borderles table-responsive-sm  text-center table">
                <tr>
                    <td>Produte</td>
                    <td>Picture</td>
                    <td>Price</td>
                    <td>comments</td>
                </tr>
                @foreach($company->protiens as $one)
                <tr>
                    <td>{{$one->type}}</td>
                    <td>
                        <a href="{{url('protien')}}/{{$one->id}}">
                            <img style="height:100px;width:100px " class="card-img" src="../uploaded/{{$one->img}}" alt="">
                        </a>
                    </td>
                    <td> $ {{$one->price}}</td>
                    <td><a href='{{url('protien')}}/{{$one->id}}'> {{$one->comments->count()}}   </a> </td>
                </tr>
                @endforeach
            </table>


</div>

@stop
