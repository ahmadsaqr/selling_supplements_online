<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/app.css')); ?>">

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/my.css')); ?>">


   <?php echo $__env->yieldContent('head'); ?>
   <?php echo $__env->yieldContent('style'); ?>
</head>


<?php
    if(Auth::check() and Auth::User()->img != "" ){
        $xx=explode("|",Auth::User()->img);
        }

    $coms= \App\Comment::where('accept',0)->count();
    $members= \App\User::where('accept',0)->count();

    function is_id($id){
         return is_numeric($id)?true:false;
         }

?>

<body>

<?php if(Auth::check()): ?>
    <?php if(Auth::user()->admin == 0): ?>

        <nav class="navbar navbar-expand-lg navbar-light bg-light">

            <a class="navbar-brand" href="<?php echo e(url('user')); ?>/<?php echo e(Auth::user()->name); ?>">
                <?php if(Auth::user()->img != '' ): ?>
                    <img class="img-user"  src="<?php echo e(url('/uploaded')); ?>/<?php echo e(end($xx)); ?>">
                <?php else: ?>
                    <span class="firstname"  style="color:orange; text-transform:capitalize">
                        <?php echo e(Auth::user()->name); ?>

                    </span>
                <?php endif; ?>
            </a>

            <a style="color:orange; text-transform:capitalize" class="navbar-brand" href="<?php echo e(url('company')); ?>">
                <span>
                    Our-Provid ers
                </span>
            </a>



            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>


             <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">

                    <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(url('/protien')); ?>">
                               <span>
                                    Supplemnts <i style="color:black" class="fas fa-heart"></i>
                                </span>
                            </a>
                    </li>


                    
                      <?php if(request()->segment(1) !== 'checkOut'): ?> 
                        <?php if(session()->has('cart')): ?>
                            <?php if(session()->get('cart')->tq >0): ?>   
                                
                                <li class="nav-item">
                                 <span class="XcheckOut">
                                     (<?php echo e(session()->get('cart')->tq); ?>)
                                     <a style="color:orange" href="<?php echo e(url('/checkOut')); ?>">
                                        <i  class="fas fa-shopping-cart"></i> 
                                     </a>
                                   </span> 
                                 </li>           

                            <?php endif; ?>      
                        <?php endif; ?>        
                        <?php else: ?>
                         <li class="nav-item">
                            <span class="XcheckOut">
                              <i class="fas fa-shipping-fast"></i>
                           </span>
                         </li>  
                        <?php endif; ?>
                       
                        

                    <li class="nav-item">
                        <a class="navbar-right  signout nav-link" href="<?php echo e(url('signout')); ?>">
                             <span>
                                SingOut <i style="color:black" class="fas fa-sign-out-alt"></i>
                            </span>
                        </a>
                    </li>

                </ul>
             </div>
        </nav>
    <?php endif; ?>
<?php endif; ?>



<?php if( Auth::check()): ?>
    <?php if(Auth::user()->admin==1): ?>
         <nav class="navbar navbar-expand-lg navbar-light bg-light">

             <a pic="yes" class="navbar-brand" href="<?php echo e(url('user')); ?>/<?php echo e(Auth::user()->name); ?>">
                 <?php if(Auth::user()->img != '' ): ?>
                     <img class="img-user" src="<?php echo e(url('/uploaded')); ?>/<?php echo e(end($xx)); ?>">
                 <?php else: ?>
                     <span class="firstname" firstname="yes" style="color:orange; text-transform:capitalize">
                         <?php echo e(Auth::user()->name); ?>

                     </span>
                 <?php endif; ?>
             </a>


             <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                 <span class="navbar-toggler-icon"></span>
             </button>


            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">


                <li class="nav-item ">
                    <?php if(Request::segment(1)  !== 'company'): ?>
                        <a class="navbar-brand" href="<?php echo e(url('company')); ?>">
                            <span style="font-size:30px; color:orange; text-transform:capitalize">
                                Our-Suppliers
                            </span>
                        </a>
                    <?php endif; ?>
                </li>

                <li class="nav-item ">
                <?php if(Request::segment(2) !== 'create'): ?>
                    <a class="nav-link" href="<?php echo e(url('/protien/create')); ?>">
                        <span>NewProtien<i style="color: black" class="fas fa-plus"></i></span>
                    </a>
                <?php endif; ?>
                </li>


                <li class="nav-item ">
                <?php if(Request::segment(1) !== 'mycv'): ?>
                    <a class="nav-link" href="<?php echo e(url('/mycv')); ?>">
                        <span>
                            My-CV <i  class="far fa-file" style="color:black"></i>
                        </span>

                    </a>
                <?php endif; ?>
                </li>


            
                <li class="nav-item ">
                <?php if(is_id(Request::segment(2)) and Request::segment(1) == 'protien'): ?>
                    <a class="nav-link" href="<?php echo e(url('/protien')); ?>">
                        <span>
                            Supplemnts <i style="color:black" class="fas fa-heart"></i>
                        </span>
                    </a>
                <?php endif; ?>
                </li>

                <li class="nav-item ">
                    <?php if(Request::segment(1) !== 'protien'): ?>
                        <a class="nav-link" href="<?php echo e(url('/protien')); ?>">
                            <span>
                                Supplemnts <i style="color:black" class="fas fa-heart"></i>
                            </span>
                        </a>
                    <?php endif; ?>
                </li>


                <li class="nav-item ">
                <?php if(Request::segment(1) !== 'settings'): ?>
                        <a class="nav-link" href="<?php echo e(url('settings')); ?>">
                        <span>
                            Settings
                             <i style="color: black" class="fas fa-cogs"></i>
                        </span>

                        <?php if($coms >0): ?>
                            <span  class="navbar-brand badge" style="margin-right:-5px;background-color: #fd7e14 ">
                                <i class="fas fa-comment"></i>
                            <?php echo e($coms); ?>

                            </span>
                        <?php endif; ?>

                        <?php if($members>0): ?>
                            <span class="navbar-brand badge" style="background-color: #fd7e14 ">
                            <i class="fas fa-users"></i>
                                <?php echo e($members); ?>

                            </span>
                        <?php endif; ?>

                    </a>
                <?php endif; ?>
                </li>



 <?php if(request()->segment(1) !== 'checkOut'): ?> 
                        <?php if(session()->has('cart')): ?>
                            <?php if(session()->get('cart')->tq >0): ?>   
                                
                                <li class="nav-item">
                                 <span class="XcheckOut">
                                     (<?php echo e(session()->get('cart')->tq); ?>)
                                     <a style="color:orange" href="<?php echo e(url('/checkOut')); ?>">
                                        <i  class="fas fa-shopping-cart"></i> 
                                     </a>
                                   </span> 
                                 </li>           

                            <?php endif; ?>      
                        <?php endif; ?>        
                        <?php else: ?>
                         <li class="nav-item">
                            <span class="XcheckOut">
                              <i class="fas fa-shipping-fast"></i>
                           </span>
                         </li>  
                        <?php endif; ?>


                    <li class="nav-item">
                        <a class="nav-link signout " href="<?php echo e(url('/signout')); ?>">
                            <span>
                                SingOut <i style="color:black" class="fas fa-sign-out-alt"></i>
                            </span>
                        </a>
                    </li>
            </ul>
        </div>
    </nav>

    <?php endif; ?>
<?php endif; ?>




<?php if(! Auth::check()): ?>

        <nav class="navbar navbar-expand-lg navbar-light bg-light">

            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

          <div class="collapse navbar-collapse " id="navbarNav">
                <ul class="navbar-nav">

                    <li class="nav-item active">
                        <a class="x nav-link" href="<?php echo e(url('login')); ?>">
                            login
                        </a>
                    </li>

                    <li class="nav-item  ">
                        <a class="x nav-link " href="<?php echo e(url('register')); ?>">
                            register
                        </a>
                     </li>
                </ul>
        </div>
    </nav>
<?php endif; ?>


<div>
    <?php echo $__env->yieldContent('mesg'); ?>
</div>


<br><br><br><br>


<footer id="footer">
    Quick Picks Convenience Store - Mission Bay
</footer>


<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>

<?php echo $__env->yieldContent('script'); ?>


</body>
</html>
<?php /**PATH C:\Users\ahmad\Desktop\updated\blog\resources\views/protien/master.blade.php ENDPATH**/ ?>