<div id="acor" style="background-color:##00bffd">
<div class="text-center" style="opacity: .45" >
<div id="pics" class=" carousel slide" data-ride="carousel">

    <div class="carousel-inner">

        <div class="carousel-item active">
            <img class="img-fluid"  src="<?php echo e(url('1.jpg')); ?>" alt="...">
            <div class="carousel-caption ">
                <h5>Awesome..!</h5>
            </div>
        </div>

        <div class="carousel-item ">
            <img class="img-fluid"  src="<?php echo e(url('2.jpg')); ?>" alt="...">
            <div class="carousel-caption ">
                <h5>Great workOut</h5>
            </div>
        </div>

        <div class="carousel-item ">
            <img class="img-fluid"  src="<?php echo e(url('3.jpg')); ?>" alt="...">
            <div class="carousel-caption ">
                <h5>Success</h5>
            </div>
        </div>

    </div>

    <a class="carousel-control-prev" href="#pics" role="button" data-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="sr-only">Previous</span>
    </a>

    <a class="carousel-control-next" href="#pics" role="button" data-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="sr-only">Next</span>
    </a>

</div>
</div></div><?php /**PATH C:\Users\ahmad\Desktop\updated\blog\resources\views/protien/acor.blade.php ENDPATH**/ ?>