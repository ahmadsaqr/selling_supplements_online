<?php $__env->startSection('mesg'); ?>



<?php echo $__env->make('protien.acor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><br>

<?php if($errors->has('double-comment')): ?>
    <script >
        alert('You are only allowed of one comment');
    </script>
<?php endif; ?>


<?php if(session()->has('mesg')): ?>
    <div style="text-align: center;" class="text-center btn btn-info" >
            <?php echo e(session()->get('mesg')); ?>

    </div>
<?php endif; ?>





<div class="container">
    <div class="row">
        <?php $__currentLoopData = $all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $one): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <div id="protienbox" class="col-sm-5 col-md-3  col-xl-2 ">

                <a style="display:inline-block" href="<?php echo e(url('company')); ?>/<?php echo e($one->company->id); ?>">
                    <?php if($one->company->img): ?>
                       <img class="img-company"
                            src="<?php echo e($one->company->name); ?>.<?php echo e($one->company->img); ?>">
                    <?php else: ?>
                        <img class="img-thumbnail img-responsive img-company"
                             src="<?php echo e(url('com.png')); ?>">
                    <?php endif; ?>
                </a>

                <div class="price">
                    <b>
                        $<?php echo e($one->price); ?>

                    </b>
                </div>


              <div class="text-center" id="buynow">
                <a href="<?php echo e(url('protien')); ?>/<?php echo e($one->id); ?>">
                    <?php if($one->img === 'fakeNull.jpg' || $one->img === '' ): ?>
                        <img class="x card-img"
                             style="width:130px;height:130px;display:block; margin:0 auto"
                             src="<?php echo e(url('wow.png')); ?>">
                    <?php else: ?>
                        <img class="x card-img"
                             style="width:130px;height:130px;display:block;margin:0 auto"
                             src="<?php echo e(url('uploaded')); ?>/<?php echo e($one->img); ?>" >
                    <?php endif; ?>
                </a>
                  <a href='<?php echo e(url("buynow/".$one->id)); ?>' >Buy Now</a>
                  <br>

              </div>




      <div class="text-center">
          <?php if(Auth::user()): ?>
             <?php if(Auth::user()->admin === 1): ?>


            <form style="display:inline" action="protien/<?php echo e($one->id); ?>" method="post">
                      <?php echo csrf_field(); ?>
                      <?php echo method_field('DELETE'); ?>
                      <input type="checkbox" name="del[]" value="<?php echo e($one->id); ?>">
                      <span class="btn btn-danger" style="margin-bottom:15px !important;padding: 3px">
                      <input style="font-weight: bolder;margin-left: -5px;
                                  background-color: transparent; border-color: transparent" 
                                  type="submit"  value='Del'>

                      <i class="fas fa-trash fa-2x" style="margin-left:-8px"></i>
                      </span>
            </form>

                        <a class="admin" href="protien/<?php echo e($one->id); ?>/edit">
                            <i style="margin-bottom:15px !important" class="far fa-edit fa-2x btn btn-info"></i>
                        </a>
                    <?php endif; ?>
                <?php endif; ?>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>




<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>




<?php echo $__env->make('protien.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ahmad\Desktop\updated\blog\resources\views/protien/index.blade.php ENDPATH**/ ?>