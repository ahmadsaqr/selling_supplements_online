<?php $__env->startSection('mesg'); ?>
    <br><br><br>
    
        
        <div style="text-align: center; opacity:0.7">

            <style>
                .x{color: red}
            </style>

              <div class="container">
                  <div style="width: 30%; height: 30%; margin:auto; margin-top: 200px">
                  <h2 class="container">Login Form</h2>  
                   <?php echo Form::open(['url' => 'login']); ?>

                   <?php echo Form::text('email',old('email'),['class' => 'form-control','placeholder' =>'email']); ?>

                   <?php echo Form::password('password',['class' => 'form-control','placeholder' =>'password']); ?>

                   <?php echo Form::submit('Welcome',['class' => 'form-control btn btn-primary','name' => 'submit' ]); ?>

                   <?php echo Form::close(); ?>

                  </div>
              </div>      




        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if( $error  === "YOU NOT AUTHORISED"): ?>
              <center>
                  <h1 >YOU NOT AUTHORISED BECAUSE YOU HAVE BEEN REGISTERED </h1>
              </center>
           <?php elseif($error  === 'What are you doing mate ?!'): ?>
                <center>
                    <h1 >What the fuck  that you doing mate ?!</h1>
                </center>
           <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php if($errors->has('wait')): ?>
            <center>
               <h1><?php echo e($error); ?></h1>
            </center>
        <?php endif; ?>

        <?php if($errors->has('not-valid')): ?>
            <center>
                <h1><?php echo e($error); ?></h1>
            </center>
        <?php endif; ?>

        <?php if($errors->has('comment-reject')): ?>
            <center>
                <h1>YOU CAN'T MAKE COMMENT WHILE YOU NOT REGISTERED !</h1>
            </center>
        <?php endif; ?>

        <?php if($errors->has('buyNow')): ?>           
        <H1 class="alert alert-danger "><?php echo e($error); ?></H1> 
        <?php endif; ?>  



    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('loginRegister.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ahmad\Desktop\updated\blog\resources\views/loginRegister/login.blade.php ENDPATH**/ ?>