<?php $__env->startSection('head'); ?>
    <style>
        body{background: black;
            color:white;
            font-weight: bolder;
            font-size: 21px}
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('mesg'); ?>
    <h3 class="offset-sm-4"><br>
        People Say About <?php echo e($protien->type); ?> <br> that coming from  <a href="<?php echo e(url('company')); ?>/<?php echo e($protien->company->id); ?>"><?php echo e($protien->company->name); ?>-company</a>
    </h3><br>


<div CLASS="container">
    <div class="row">

        <div class="col-sm-3" style="border-right:2px solid black">
            <?php if($protien->img === 'fakeNull.jpg' || $protien->img === ''): ?>
                <div>
                   <br><br>
                    <img class="img-fluid" src="<?php echo e(url('bgProtien.jpg')); ?>">
                </div>
            <?php else: ?>
                <div>
                    <img src="<?php echo e(url('uploaded')); ?>/<?php echo e($protien->img); ?>" class="img-fluid" >
                </div>
            <?php endif; ?>
                <br>
        </div>


        <div class="col-sm-8">
            <?php $__currentLoopData = $protien->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $one): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($one->accept == 1): ?>
                <div>
                    <p class="lead text-capitalize font-weight-bold">
                        <mark><?php echo e($one->custmor); ?></mark>
                        Says: <?php echo e($one->body); ?>

                </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <form style="opacity:.7" method="post" action="<?php echo e(url('comment/'.$protien->id)); ?>" class="form-group">
                <?php echo e(csrf_field()); ?>

                <input name="company_id" type="hidden" value="<?php echo e($protien->company_id); ?>">
                <input class="form-control" type="hidden" placeholder="what is your name?" name='custmor'>
                <textarea class="form-control" placeholder="Say something...?" name="body"></textarea>
                <input name="submit" class="btn btn-success" type="submit" value="Add comment">
            </form>

        </div>
    </div>
    <hr>


</div>

<?php if($errors->has('comment')): ?>
    <script >
        alert('you can not make another comment');
    </script>
<?php endif; ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('protien.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ahmad\Desktop\updated\blog\resources\views/protien/show.blade.php ENDPATH**/ ?>