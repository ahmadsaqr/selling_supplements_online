<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class Protien extends Model
{
    protected $fillable=['type','price'];

    public function comments(){
        return $this->hasMany(\App\Comment::class)->orderByDesc('created_at');
    }

    public function company(){
        return $this->belongsTo(\App\Company::class);
    }
}
