<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Company extends Model
{
    protected $fillable=['name','img'];

    public function protiens(){
        return $this->hasMany(\App\Protien::class);
    }

    public function comments(){
        return $this->hasMany(\App\Comment::class);
    }

    protected $table='companies';
}
