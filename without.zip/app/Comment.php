<?php

namespace App;
use Illuminate\Support\Facades\Auth;

use Illuminate\Database\Eloquent\Model;

class Comment extends Model
{
    protected $fillable=['body','protien_id','custmor','accept','company_id'];

    protected $table='comments';

    public function protien(){
        return $this->belongsTo(\App\Protien::class);
    }

    public function company(){
        return $this->belongsTo(\App\Company::class);
    }

    protected $attributes = ['accept' => 0];
}
