<?php


namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\User;
use App\Admin;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use App\Http\Requests\shortCutData;
use Illuminate\Support\Facades\Session;
use App\Cart;

class loginRegister extends Controller
{
    public function createRegister()
    {
        return view('loginRegister.register');
    }


    public function createLogin()
    {
        return view('loginRegister.login');
    }


    public function mesg(Request $request){
        session()->put('mesg', $request->mesg);
        return back();
    }


    public function checkLogin(Request $request)
    {
        if ($request->has('submit')) {

            $accept = User::where('email', $request->email)->value('accept');
            $email_user = User::where('email', $request->email)->value('email');

            if (Auth::Attempt(['password' => $request->password, 'email' => $request->email, 'admin' => 0,'accept' => 1])) {

                    return redirect ('protien');   
            }
                 
            


             else if (Auth::Attempt(['password' => $request->password, 'email' => $request->email, 'accept' => 1, 'admin' => 1])) {
                return redirect('/settings');
            }


            else if ($email_user === $request->email and $accept === 0) {
                return redirect()->back()->withErrors(['wait' => 'WE ARE CONSIDERING YOUR MEMBERSHIP ATM.... WAIT PLEASE ' ]);
            }

            else  {
                return redirect()->back()->withErrors(['not-valid' => 'You are not register yet it or Your information are wrong']);
            }

        }
    }


    public function membership(Request $request){
      if($request->has('accept')){
          User::find($request->user_id)->update(['accept'=>1]);
          return back();
      }

      else{
          User::find($request->user_id)->delete();
          return back();
      }
    }


    public function upgrage(Request $request){

        if($request->has('accept')){

            User::find($request->user_id)->update(['admin'=>1]);
            $user_email=User::where('id',$request->user_id)->value('email');
            Admin::create(['email' =>$user_email]);

            return back();
        }


        if($request->has('downgrage')){

            User::find($request->user_id)->update(['admin'=>0]);
            $user_email=User::where('id',$request->user_id)->value('email');
            Admin::where('email',$user_email)->delete();

            return back();
        }
    }



    public function storeRegister(shortCutData $request)
    {
        if($request->has('submit')){  // dd($request->input());
//                                          $validated = $request->validated();

            $data['password']=bcrypt($request->password);
            $data['name']=$request->name;
            $data['email']=$request->email;
            $data['accept']=0;
            $data['admin']=0;
            $data['img']='';

            User::create($data);   //        Auth::login($newUser);   //or login Auth()->login($newUser);
            return redirect('protien');
        }

        else{
            return back();
        }
    }


    public function signout(Request $request)
    {
        if(session()->has('cart')){
            session()->forget('cart');
        }

        Auth::logout();
        return redirect('/protien');
    }

    public function changeprofile(){
           return view('loginRegister.changeProfile');
    }


    public function updatepassword(shortCutData $request, $id){

        $user=User::find(auth()->id());

        if(Hash::check($request->oldpassword, $user->password))
        {
            if($request->newpassword1 === $request->newpassword2 ) {
                    $user->password=bcrypt($request->newpassword1);
                    $user->save();
                    Session::flash('password', 'your new password has been set');
                    return redirect()->back();
            }
            else{
                return redirect()->back()->withErrors([2 => ' ']);
            }
        }

        else{
            return redirect()->back()->withErrors([3 => ' ']);
        }

    }



    public function updateprofile(Request $request, $id)
    {
        $this->validate(request(), [
            'img.*' => 'required|image|mimes:jpg,png,jpeg'
        ]);

        if ($request->img) {

                $imgs = Request()->file('img');

                foreach ($imgs as $img) {
                    $x[] = $img->getClientOriginalName();
                    $img->move(public_path('/uploaded'),$img->getClientOriginalName());
                }

                \App\User::find($id)->update(['img' => implode("|",$x)]);
                return back();


        }
        else{
            return back()->withErrors(['mesg' => 'please upload a picture picture']);
        }


    }


    public function showComments(){
          $x = DB::table('comments')->select('body','protien_id')
                                          ->where('custmor',auth()->user()->name)
                                          ->orderByDesc('created_at')
                                          ->get();



//          DB::table('users')->where('email', '=', 'xx@xx.com')->delete()->dd();



        return view('loginRegister.changeprofile',compact('x'));
    }



}

