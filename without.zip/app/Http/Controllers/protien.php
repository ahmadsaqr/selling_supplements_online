<?php

namespace App\Http\Controllers;
use App\Http\Requests\shortCutData;
use Illuminate\Http\Request;
use App\Company;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;
use App\Cart;
use Cartalyst\Stripe\Laravel\Facades\Stripe;


class protien extends Controller
{

    public function payment(Request $request){
       

        $charge=Stripe::charges()->create([
                'currency'     => 'USD',
                'source'      =>$request->stripeToken,
                'amount'      =>$request->amount,
                'description' =>'yesyes'
    
        ]);

        $chargeId= $charge['id'];

        if($chargeId){
           session()->forget('cart');
           return redirect ('/protien');
        }
        else{
            return back();
        }

    }

    public function checkOutEdit(Request $request,\App\Protien $protien){
        $this->validate(request(), [
            'quntity' => ' numeric'
        ]);

        if($request->quntity > 0){
            $newQuntity=$request->quntity;    
        }   

        else{
            $newQuntity=1;
        }

        $cart = new Cart(session()->get('cart'));
        $cart->edit($protien, $newQuntity);
        session()->put('cart',$cart);
        return back(); 
    }



    public function checkOutDelete(\App\Protien $protien){

            $cart=new Cart(Session()->get('cart'));
            $cart->delete($protien);
            session()->put('cart',$cart);
            return back(); 
    }

    public function checkout(){
        if(session()->has('cart')){
               $cart= new Cart(session()->get('cart'));
                if($cart->tq > 0){
                    return view('checkout',compact('cart'));    
                }
                else{
                    return redirect('protien');
                }       
           }
    }


    public function buynow(\App\Protien $protien){
       if( auth()->user()){
           if(session()->has('cart')){
               $cart= new Cart(session()->get('cart'));
           }
           else{
               $cart=new Cart();
           }
           $cart->add($protien);
           session()->put('cart',$cart);
           return back();

       }
       else{
           return redirect('/login')->withErrors(['buyNow' => 'please register']);
       }

    }


    public function index(){

        $all = \App\Protien::all();
        $company = \App\Company::all();
        $users=\App\User::all();

//        $all = DB::table('protiens')->distinct()->get();

        return view('protien.index', compact('all','company','users'));}

    public function create(){
        $company = Company::All();
        $protien =\App\Protien::All();
        return view('protien.create',compact('company','protien'));
    }

    public function create2(){
        $company = Company::All();
        $protien =\App\Protien::All();
        return view('protien.create2',compact('company','protien'));
    }


     public function show($id){
        if(is_numeric($id)){
            $all_protiens= \App\Protien::All();
            foreach ($all_protiens as $all_ids) {
                $all[]=$all_ids->id;
            }

            if(in_array($id,$all)){
                $protien=\App\protien::find($id);
                return view('protien.show', compact('protien'));
            }

            else{
                return redirect('protien');
            }
        }
        else{
            return redirect('protien');
        }
    }


    public function destroy($id){
        \App\protien::find($id)->delete();
        \App\Comment::where('protien_id',$id)->delete();
        return redirect('/protien');
    }


    public function edit($id){

    // use this function because were error when I type /protien/4d/edit  => so by this we solve it
         if(is_numeric($id) ) {
             $protiens = \App\Protien::All();
             foreach ($protiens as $pro) {
                 $all_id[]=$pro->id;
             }
             if (in_array($id, $all_id)){
                 $protien=\App\protien::find($id);
                 $protiens = \App\Protien::All();
                 $company = \App\Company::All();
                 return view('protien.edit', compact('protien','protiens','company'));
             }

              else{
                  return url('protien'); //return redirect('protien');
              }
         }

         else{
             return redirect('protien');
         }
     }


    public function store(shortCutData $request)
    {
//        $request->flash();

        if ($request->img) {
               $img = time().$request->img->getClientOriginalName();
               $com = Company::where('name', $request->company_id)->value('id');

                $new = new \App\Protien;
                    $new->type = $request['type']; //  $new->type = $request->type;
                    $new->company_id = $com;
                    $new->price = $request->price;
                    $new->img = $img;
                $new->save();

                $request->img->move(public_path('/uploaded'), $img);
                return redirect('/protien');
        }
        else {
                $request->img = 'fakeNull.jpg';
                $com = Company::where('name', $request->company_id)->value('id');

                $new = new \App\Protien;
                    $new->type = $request->type;
                    $new->company_id = $com;
                    $new->price = $request->price;
                    $new->img = $request->img;
                $new->save();
                return redirect('/protien');
        }
    }


    public function update(shortCutData $request, $id)    //This request don't process or update picture
    {
        $com = Company::where('name', $request->company_id)->value('id');
        $update = \App\Protien::find($id);
        $update->type = $request->type;
        $update->company_id = $com;
        $update->price = $request->price;
        $update->save();
        return redirect('/protien');
    }



     public function search (Request $request){
        $data=\App\Protien::where('price','like','%'.$request->search.'%')->get();
//        print_r($data);
         dd($data);
            return  view('protien.index',compact('data'));
     }

}
