<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\DB;

class comment extends Controller
{
    public function store(Request $request, $id)
    {

        if(Auth::check()) {

            $x=DB::table('comments')
                ->where('protien_id', $id)
                ->where('custmor', auth()->user()->name)
                ->exists();


            if (!$x and auth()->user()->admin===0) {
                $data = $this->validate(request(), ['body' => 'required|string']);
                $data['custmor'] = Auth::user()->name;
                $data['protien_id'] = $id;
                $data['company_id'] = $request->company_id;
//                $data['accept'] = 0; ===========> model ::  protected $attributes = [ 'accept' => 0,];
                \App\Comment::create($data);
                Session::flash('mesg', 'your comment will be added soon');
                return redirect('/protien');
            }


            if( $x and auth()->user()->admin===0 ){
                return redirect(url('protien/'))->withErrors(['double-comment' => ' ' ]);
            }


            if(!$x OR $x and auth()->user()->admin===1){
                $data = $this->validate(request(), ['body' => 'required|string']);
                $data['accept'] = 1;
                $data['custmor'] = Auth::user()->name;
                $data['protien_id'] = $id;
                $data['company_id'] = $request->company_id;
                \App\Comment::create($data);
                return redirect('/protien');
            }
        }

        else {
            return redirect('/login')->withErrors(['comment-reject' => ' ']);
        }

    }
}




