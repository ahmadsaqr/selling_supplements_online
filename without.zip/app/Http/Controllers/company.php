<?php

namespace App\Http\Controllers;


use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\User;
use Illuminate\Support\Facades\File;
class company extends Controller
{
    public function company(){
        return view('allCompanies');
    }


    public function companyName($id,Request $request){
        $com= \App\Company::find($id);
        $all= \App\Company::All();


        foreach ($all as $one) {
            $ids[] = $one->id;
            $ids = array_values($ids);
        }

        if(is_numeric($request->segment(2)) ){
            if(in_array($request->segment(2),$ids )){

                $next = \App\Company::where('id', '>', $request->segment(2))->orderBy('id', 'desc')->value('id');
                $last = \App\Company::where('id', '>', $request->segment(2))->orderBy('id')->value('id');

                $previous = \App\Company::where('id', '<', $request->segment(2))->orderBy('id','desc')->value('id');
                $first = \App\Company::where('id', '<', $request->segment(2))->orderBy('id')->value('id');
            }
            else{
             return back();
           }
        }

        else{
            if(starts_with($request->segment(2),'?')) {
                return redirect('company/3');
            }
            return redirect('company/1');
        }

        return view('company',['company' => $com , 'last' => $last, 'next' => $next,'previous' => $previous, 'first' => $first ]);
    }

}
