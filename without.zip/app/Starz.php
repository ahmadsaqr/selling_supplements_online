<?php

namespace App;

use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;

class User extends Authenticatable
{
    use Notifiable;

    protected $fillable = ['admin','name', 'email', 'password','img','accept'];
//    protected $guarded = [];
    protected $hidden = ['password', 'remember_token',];

    public function roles(){
     return $this->belongsToMany('\App\Role','role-user','user_id','role_id');
    }

}
