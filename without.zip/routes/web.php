<?php
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// route::post('search','protien@search');



route::get('buynow/{protien}','protien@buynow');
route::get('checkOut','protien@checkOut');
route::post('checkOutDelete/{protien}','protien@checkoutDelete');
route::post('checkOutEdit/{protien}','protien@checkOutEdit');
route::post('payment','protien@payment');



route::get('/','protien@index');
route::resource('protien','protien');


route::get('company/{id}','company@companyName');
route::get('company','company@company');


route::group(['middleware' => 'guest'], function() {

    route::get('/register', 'loginRegister@createRegister');
    route::get('/login', 'loginRegister@createLogin');
    route::post('/login', 'loginRegister@checkLogin');
    route::post('/register', 'loginRegister@storeRegister');

});


route::group(['middleware' => 'settings'], function() {

    route::resource('ahmad/starz','test\test');
    route::delete('ahmad/starz/{id?}','test\test@destroy');
    route::post('membership','loginRegister@membership');
    route::post('upgrage','loginRegister@upgrage');


    route::get('/settings', 'settings@create_company');
    route::post('/settings', 'settings@store_company');
    route::delete('/settings', 'settings@destroy_company');
    route::put('/acceptcomment','settings@acceptcomment');
    route::delete('/deletecomment','settings@deletecomment');
    route::put('/editcomment','settings@editcomment');


    route::get('protien/create','protien@create');
    route::get('protien/{protien}/edit','protien@edit');
    route::delete('protien/{protien}','protien@destroy');
    route::post('protien/{protien}','protien@store');
    route::put('protien/{protien}','protien@update');
    route::put('/protien2/{id}','protien2@update');  //img edit and remember patch only go with laravelcollective !!

    route::get('/mycv',function(){return view('mycv');} );
    route::get('/mycv2',function(){return view('mycv2');} );
});


route::group(['middleware' => 'auth'],function (){

    route::get('user/{name}','loginRegister@changeprofile');
    route::post('user','loginRegister@mesg');

    route::get('user/{name}','loginRegister@showComments');
    route::get('signout','loginRegister@signout');
    route::put('user/{id}','loginRegister@updatepassword');
    route::post('user/{id}','loginRegister@updateprofile');

});


route::get('nf',function (){
    return view('nf');
});

route::post('comment/{id}','comment@store');