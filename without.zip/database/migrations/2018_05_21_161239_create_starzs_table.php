<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateStarzsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('starzs', function (Blueprint $table) {
            $table->increments('id');
//            $table->integer('timesheet_id');
            $table->string('name');
            $table->string('position')->default('trainer');
            $table->integer('mobile');
            $table->timestamps();
        });
    }


    public function down()
    {
        Schema::dropIfExists('starzs');
    }
}
