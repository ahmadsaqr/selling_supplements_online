<?php

use Illuminate\Database\Seeder;
use App\Protien;
use App\Company;


class seedme extends Seeder
{
    public function run()
    {
        $name=['','optimumnutrition','ruleoneproteins','iammutant',
               'ronniecoleman','balancesportsnutrition','giantsupps','steel','arnold'];
        for ($i=1;$i<count($name);$i++){
            $x= new Company();
            $x->id         = $i;
            $x->name       = $name[$i];
            $x->img        = 'jpg';
            if($name[$i]==='iammutant'){
                $x->img        = 'png';
            }
            $x->save();
        }


        for ($i=1;$i<=40;$i++){

            $w= new Protien();

            $type=['Isolated Whey Protein', 'Fat Burner' , 'Whey Protein', 'Mass Gainer', 'BSAAs', 'preWorkOut'];
            $random_array_keys=array_rand($type,1);



            $company=\App\Company::All();
            foreach ($company as $one){
                $company_id[]=$one->id;
            }
            $random_array_keys2=array_rand($company_id,1);




            $x = 0;
            while($x < 7) {
                $url_imgs[] = $x.'.jpg';
                $x++;
            }

            $random_array_keys3=array_rand($url_imgs,1);



            $w->id         = $i;
            $w->type       = $type[$random_array_keys];
            $w->price      = rand(35,199);
            $w->img        = $url_imgs[$random_array_keys3];
            $w->company_id = $company_id[$random_array_keys2];
            $w->save();
        }
    }
}
