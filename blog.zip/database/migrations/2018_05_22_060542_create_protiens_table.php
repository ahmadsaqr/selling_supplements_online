<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateProtiensTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('protiens', function (Blueprint $table) {
            $table->increments('id');
//            $table->enum('type',['Isolated Whey Protein', 'Whey Protein', 'Mass Gainer', 'BSAAs', 'preWorkOut','Fat Burner']);
            $table->string('type');
            $table->integer('price');
            $table->string('img');
            $table->integer('company_id');
            $table->timestamps();
        });
    }

    public function down()
    {
        Schema::dropIfExists('protiens');
    }
}
