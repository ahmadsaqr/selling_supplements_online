<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTimesheetsTable extends Migration
{

    public function up()
    {
        Schema::create('timesheets', function (Blueprint $table) {
            $table->increments('id');

            $table->integer('starz_id');
            // name of employye table is starz

            for($i=1;$i<=31;$i++){
                $table->integer('Jan'.$i)->nullable();
            }

            $table->timestamps();
        });
    }

    public function down()
    {
        Schema::dropIfExists('timesheets');
    }
}
