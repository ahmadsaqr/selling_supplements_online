<html lang="en">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" integrity="sha384-WskhaSGFgHYWDcbwN70/dfYBj47jz9qbsMId/iRN3ewGhXQFZCSftd1LZCfmhktB" crossorigin="anonymous">
</head>

<body style="background-color:silver">



<nav class="navbar navbar-expand-md navbar-dark bg-dark fixed-top">

    <?php switch(Request::segment(1)):
        case ('register'): ?>
            <a style="color: #fd7e14" class="x navbar-brand" href="<?php echo e(url('protien')); ?>"> Supplemts </a>
            <a style="color: #fd7e14" class="x navbar-brand" href="<?php echo e(url('login')); ?>"> Login </a>
        <?php break; ?>

        <?php default: ?>
            <a style="color: #fd7e14" class="x navbar-brand" href="<?php echo e(url('protien')); ?>"> Supplemts </a>
            <a style="color: #fd7e14" class="x navbar-brand" href="<?php echo e(url('register')); ?>"> Register</a>
            <a style="color: #fd7e14" class="x navbar-brand" href="<?php echo e(url('company')); ?>"> Our-Suppliers</a>
    <?php endswitch; ?>


</nav>
<br>

<div class="container">
    <?php echo $__env->yieldContent('mesg'); ?>
</div>

<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>

</body>
</html>
<?php /**PATH C:\Users\ahmad\Desktop\updated\blog\resources\views/loginRegister/master.blade.php ENDPATH**/ ?>