<?php $__env->startSection('mesg'); ?>

<?php $__env->startSection('head'); ?>
    <style>
        body{background: black; color:white;font-weight: bolder;}
    </style>
<?php $__env->stopSection(); ?>

    <?php
        $all= \App\Comment::all();
        $all_users= \App\User::all();

        $active=[];
        foreach ($all_users as $user){
            if($user->accept == 0){
                 $active[]=$user->accept;
            }
        }
    ?>



<div class="container setting">
<div class="row">


    <div class="col-sm-12  col-md-6 offset-lg-2 col-lg-4 ">
         <form  action='<?php echo e(url("settings")); ?>' method="post">
            <?php echo csrf_field(); ?>
             <h3 style="display: inline">Add Company</h3><br>
             <input type="text" name="name" placeholder="company"><br>
             <input type="submit" name="submit" value="Add Company">
         </form>
    </div>


    <div class="col-sm-12 col-md-6">
     <form action="<?php echo e(url('settings')); ?>"  method="post">
         <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
         <h3 style="display: inline">Delete Company</h3><br>
            <select name="company">
                <?php $__currentLoopData = $com; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $one): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($one->id); ?>">   <?php echo e($one->name); ?>-<?php echo e($one->id); ?>  </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
         <br> <input type="submit" name="submit" value="Delete Company" >
     </form>
    </div>

    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $oneerror): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="btn btn-danger"> <?php echo e($oneerror); ?>   </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>
</div>

    <table class="text-center col-sm-12 table-responsive" style="border: 10px red solid">
        <thead>
        <tr>
            <td>The Comments</td>
            <td>Custmor</td>
            <td>Protien Type</td>
            <td>Protien Picture</td>
            <td>Accpetance</td>
        </tr>
        </thead>



    <?php $__currentLoopData = $all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $one): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($one->accept ==0): ?>

    <tbody>
        <tr>
        <td>
           <form style="display:inline" action="<?php echo e(url('editcomment')); ?>" method="post">
               <?php echo csrf_field(); ?>
               <?php echo method_field('PUT'); ?>
               <input type="hidden" name="commentid" value="<?php echo e($one->id); ?>">
               <input type="hidden" name="protienid" value="<?php echo e($one->protien_id); ?>">
               <input type="text" name="commentbody" value=<?php echo e($one->body); ?>>
               <input type="submit" class="btn btn-info" value="Edit">
           </form>
       </td>

       <td style="font-weight: bold"><?php echo e($one->custmor); ?></td>

       <td> <?php echo e($one->company->name); ?> - <?php echo e($one->protien->type); ?></td>

       <td>
           <?php if($one->protien->img !=='fakeNull.jpg'): ?>
                <img style="height:50px;width:50px;border-radius:50%" src="<?php echo e(url('uploaded')); ?>/<?php echo e($one->protien->img); ?>">
            <?php else: ?>
                <img style="height:50px;width:50px;border-radius:50%"  src="<?php echo e(url('wow.png')); ?>">
            <?php endif; ?>
       </td>

       <td>
           <form style="display:inline" action="<?php echo e(url('acceptcomment')); ?>" method="post">
               <?php echo e(csrf_field()); ?>

               <input type="hidden" name="_method" value="PUT">
               <input type="hidden" name="commentid" value="<?php echo e($one->id); ?>">
                   <input type="hidden" name="protienid" value="<?php echo e($one->protien_id); ?>">
               <input type="submit" class="btn btn-success" value="Accept">
           </form>

           <form style="display:inline" action="<?php echo e(url('deletecomment')); ?>" method="post">
               <?php echo e(csrf_field()); ?>

               <input type="hidden" name="_method" value="DELETE">
               <input type="hidden" name="custmor" value="<?php echo e($one->custmor); ?>">
               <input type="hidden" name="commentid" value="<?php echo e($one->id); ?>">
               <input type="submit" class="btn btn-danger" value="DELETE">
           </form>
       </td>

        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tr>
    </tbody>

</table>

<br><br><br>


     <table class="col-sm-12 text-center table table-bordered ">
         <tr>
                <td>Name</td>
                <td>Email</td>


                    <td>Membership Activation</td>


                <td>Upgrading</td>
                <td>Downgrading</td>
            </tr>

        <?php $__currentLoopData = $all_users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($user->name); ?></td>
                <td><?php echo e($user->email); ?></td>


                <td>
                    <?php if($user->accept === 0): ?>
                    <form method="post" action="membership">
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" name="user_id" value="<?php echo e($user->id); ?>">
                        <input name="accept" type="submit" value="accept">
                        <input name="reject" type="submit" value="reject">
                    </form>
                    <?php endif; ?>
                </td>




                <td>
                    <?php if($user->accept==1): ?>
                        <?php if($user->admin ==1): ?>
                                Admin
                        <?php else: ?>
                            <form method="post" action="upgrage">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="user_id" value="<?php echo e($user->id); ?>">
                                <input name="accept" type="submit" value="upGrade:)">
                            </form>
                        <?php endif; ?>
                    <?php else: ?>
                    <?php endif; ?>
                </td>


                <td><?php if($user->accept==1 and $user->admin==1): ?>
                        <?php if($user->email =='ahmadsaqr@hotmail.com'): ?>
                            SuperAdmin
                        <?php elseif($user->name==auth()->user()->name): ?>
                            you cant delete yourSelf
                        <?php else: ?>
                            <form method="post" action="upgrage">
                                <?php echo e(csrf_field()); ?>

                                <input type="hidden" name="user_id" value="<?php echo e($user->id); ?>">
                                <input type="submit" name="downgrage" value="downGrade">
                            </form>
                        <?php endif; ?>
                     <?php else: ?>
                     <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>






<?php $__env->stopSection(); ?>

<?php echo $__env->make('protien.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ahmad\Desktop\updated\blog\resources\views/settings.blade.php ENDPATH**/ ?>