@extends('loginRegister.master')

@section('mesg')
    <br><br><br>
    
        
        <div style="text-align: center; opacity:0.7">

            <style>
                .x{color: red}
            </style>

              <div class="container">
                  <div style="width: 30%; height: 30%; margin:auto; margin-top: 200px">
                  <h2 class="container">Login Form</h2>  
                   {!! Form::open(['url' => 'login']) !!}
                   {!! Form::text('email',old('email'),['class' => 'form-control','placeholder' =>'email']) !!}
                   {!! Form::password('password',['class' => 'form-control','placeholder' =>'password']) !!}
                   {!! Form::submit('Welcome',['class' => 'form-control btn btn-primary','name' => 'submit' ]) !!}
                   {!! Form::close() !!}
                  </div>
              </div>      




        @foreach($errors->all() as $error)
            @if( $error  === "YOU NOT AUTHORISED")
              <center>
                  <h1 >YOU NOT AUTHORISED BECAUSE YOU HAVE BEEN REGISTERED </h1>
              </center>
           @elseif ($error  === 'What are you doing mate ?!')
                <center>
                    <h1 >What the fuck  that you doing mate ?!</h1>
                </center>
           @endif
        @endforeach

        @if($errors->has('wait'))
            <center>
               <h1>{{$error}}</h1>
            </center>
        @endif

        @if($errors->has('not-valid'))
            <center>
                <h1>{{$error}}</h1>
            </center>
        @endif

        @if($errors->has('comment-reject'))
            <center>
                <h1>YOU CAN'T MAKE COMMENT WHILE YOU NOT REGISTERED !</h1>
            </center>
        @endif

        @if($errors->has('buyNow'))           
        <H1 class="alert alert-danger ">{{$error}}</H1> 
        @endif  



    </div>


@stop()
