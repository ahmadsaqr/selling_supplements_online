<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link rel="stylesheet" type="text/css" href="{{asset('css/app.css')}}">

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="{{asset('css/my.css')}}">


   @yield('head')
   @yield('style')
</head>


@php
    if(Auth::check() and Auth::User()->img != "" ){
        $xx=explode("|",Auth::User()->img);
        }

    $coms= \App\Comment::where('accept',0)->count();
    $members= \App\User::where('accept',0)->count();

    function is_id($id){
         return is_numeric($id)?true:false;
         }

@endphp

<body>

@if(Auth::check())
    @if(Auth::user()->admin == 0)

        <nav class="navbar navbar-expand-lg navbar-light bg-light">

            <a class="navbar-brand" href="{{url('user')}}/{{ Auth::user()->name }}">
                @if(Auth::user()->img != '' )
                    <img class="img-user"  src="{{url('/uploaded')}}/{{end($xx)}}">
                @else
                    <span class="firstname"  style="color:orange; text-transform:capitalize">
                        {{ Auth::user()->name }}
                    </span>
                @endif
            </a>

            <a style="color:orange; text-transform:capitalize" class="navbar-brand" href="{{url('company')}}">
                <span>
                    Our-Provid ers
                </span>
            </a>



            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>


             <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">

                    <li class="nav-item">
                            <a class="nav-link" href="{{url('/protien')}}">
                               <span>
                                    Supplemnts <i style="color:black" class="fas fa-heart"></i>
                                </span>
                            </a>
                    </li>


                    
                      @if(request()->segment(1) !== 'checkOut') 
                        @if(session()->has('cart'))
                            @if(session()->get('cart')->tq >0)   
                                
                                <li class="nav-item">
                                 <span class="XcheckOut">
                                     ({{session()->get('cart')->tq}})
                                     <a style="color:orange" href="{{url('/checkOut')}}">
                                        <i  class="fas fa-shopping-cart"></i> 
                                     </a>
                                   </span> 
                                 </li>           

                            @endif      
                        @endif        
                        @else
                         <li class="nav-item">
                            <span class="XcheckOut">
                              <i class="fas fa-shipping-fast"></i>
                           </span>
                         </li>  
                        @endif
                       
                        

                    <li class="nav-item">
                        <a class="navbar-right  signout nav-link" href="{{url('signout')}}">
                             <span>
                                SingOut <i style="color:black" class="fas fa-sign-out-alt"></i>
                            </span>
                        </a>
                    </li>

                </ul>
             </div>
        </nav>
    @endif
@endif



@if( Auth::check())
    @if(Auth::user()->admin==1)
         <nav class="navbar navbar-expand-lg navbar-light bg-light">

             <a pic="yes" class="navbar-brand" href="{{url('user')}}/{{ Auth::user()->name }}">
                 @if(Auth::user()->img != '' )
                     <img class="img-user" src="{{url('/uploaded')}}/{{end($xx)}}">
                 @else
                     <span class="firstname" firstname="yes" style="color:orange; text-transform:capitalize">
                         {{ Auth::user()->name }}
                     </span>
                 @endif
             </a>


             <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                 <span class="navbar-toggler-icon"></span>
             </button>


            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">


                <li class="nav-item ">
                    @if(Request::segment(1)  !== 'company')
                        <a class="navbar-brand" href="{{url('company')}}">
                            <span style="font-size:30px; color:orange; text-transform:capitalize">
                                Our-Suppliers
                            </span>
                        </a>
                    @endif
                </li>

                <li class="nav-item ">
                @if(Request::segment(2) !== 'create')
                    <a class="nav-link" href="{{url('/protien/create')}}">
                        <span>NewProtien<i style="color: black" class="fas fa-plus"></i></span>
                    </a>
                @endif
                </li>


                <li class="nav-item ">
                @if(Request::segment(1) !== 'mycv')
                    <a class="nav-link" href="{{url('/mycv')}}">
                        <span>
                            My-CV <i  class="far fa-file" style="color:black"></i>
                        </span>

                    </a>
                @endif
                </li>


            {{-- how to show supplemnts page on show and edit page --}}
                <li class="nav-item ">
                @if(is_id(Request::segment(2)) and Request::segment(1) == 'protien')
                    <a class="nav-link" href="{{url('/protien')}}">
                        <span>
                            Supplemnts <i style="color:black" class="fas fa-heart"></i>
                        </span>
                    </a>
                @endif
                </li>

                <li class="nav-item ">
                    @if(Request::segment(1) !== 'protien')
                        <a class="nav-link" href="{{url('/protien')}}">
                            <span>
                                Supplemnts <i style="color:black" class="fas fa-heart"></i>
                            </span>
                        </a>
                    @endif
                </li>


                <li class="nav-item ">
                @if(Request::segment(1) !== 'settings')
                        <a class="nav-link" href="{{url('settings')}}">
                        <span>
                            Settings
                             <i style="color: black" class="fas fa-cogs"></i>
                        </span>

                        @if($coms >0)
                            <span  class="navbar-brand badge" style="margin-right:-5px;background-color: #fd7e14 ">
                                <i class="fas fa-comment"></i>
                            {{$coms}}
                            </span>
                        @endif

                        @if($members>0)
                            <span class="navbar-brand badge" style="background-color: #fd7e14 ">
                            <i class="fas fa-users"></i>
                                {{$members}}
                            </span>
                        @endif

                    </a>
                @endif
                </li>



 @if(request()->segment(1) !== 'checkOut') 
                        @if(session()->has('cart'))
                            @if(session()->get('cart')->tq >0)   
                                
                                <li class="nav-item">
                                 <span class="XcheckOut">
                                     ({{session()->get('cart')->tq}})
                                     <a style="color:orange" href="{{url('/checkOut')}}">
                                        <i  class="fas fa-shopping-cart"></i> 
                                     </a>
                                   </span> 
                                 </li>           

                            @endif      
                        @endif        
                        @else
                         <li class="nav-item">
                            <span class="XcheckOut">
                              <i class="fas fa-shipping-fast"></i>
                           </span>
                         </li>  
                        @endif


                    <li class="nav-item">
                        <a class="nav-link signout " href="{{url('/signout')}}">
                            <span>
                                SingOut <i style="color:black" class="fas fa-sign-out-alt"></i>
                            </span>
                        </a>
                    </li>
            </ul>
        </div>
    </nav>

    @endif
@endif




@if(! Auth::check())

        <nav class="navbar navbar-expand-lg navbar-light bg-light">

            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

          <div class="collapse navbar-collapse " id="navbarNav">
                <ul class="navbar-nav">

                    <li class="nav-item active">
                        <a class="x nav-link" href="{{url('login')}}">
                            login
                        </a>
                    </li>

                    <li class="nav-item  ">
                        <a class="x nav-link " href="{{url('register')}}">
                            register
                        </a>
                     </li>
                </ul>
        </div>
    </nav>
@endif


<div>
    @yield('mesg')
</div>


<br><br><br><br>


<footer id="footer">
    Quick Picks Convenience Store - Mission Bay
</footer>


<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>

@yield('script')


</body>
</html>
