@extends('protien.master')
@section('head')
    <style>
        body{background: black;
            color:white;
            font-weight: bolder;
            font-size: 21px}
    </style>
@endsection

@section('mesg')
    <BR>

    <h3 style="text-align: center">type information of new supplemtns... </h3>

    @php
        foreach($protien as $pro){
            $types[]=$pro->type;
            $uni=array_unique($types);
            }

    $pro_type=['Isolated Whey Protein',
               'Fat Burner' ,
               'Whey Protein',
               'Mass Gainer',
               'BSAAs',
               'preWorkOut'];
    @endphp





    <div class="container col-lg-6" style="text-align: center;opacity: .8 ">
            <form class="form-group" method="POST" action="{{url('protien')}}" enctype="multipart/form-data">

                {{csrf_field()}}

                <select  name='type' class="form-control">
                    <option disabled selected>Type your Supplemnt's Name !</option>
                    @foreach($pro_type as $type)
                        <option value="{{$type}}">{{$type}}</option>
                    @endforeach
                </select>



                <select name='company_id' class="form-control">
                    <option disabled selected>Type your Supplemnt's Company!</option>
                    @foreach($company as $com)
                     <option value="{{$com->name}}">
                         {{$com->name}}
                     </option>
                    @endforeach
                </select>


                <input value="{{old('price')}}" class="form-control" type="text"  name="price" placeholder="Price of Your Supplemnts">
                <input class="form-control" type="file" name="img" value="upload" >
                <input class="form-control btn btn-success" type="submit" value="Add New supplemtns">
            </form>

        @foreach($errors->all() as $one)
            <div> {{$one}} </div>
        @endforeach


    </div>


@endsection
