@extends('protien.master')

@section('head')
    <style>
        body{background: black;
            color:white;
            font-weight: bolder;
            font-size: 21px}
    </style>
@endsection

@section('mesg')
    <h3 class="offset-sm-4"><br>
        People Say About {{$protien->type}} <br> that coming from  <a href="{{url('company')}}/{{$protien->company->id}}">{{$protien->company->name}}-company</a>
    </h3><br>


<div CLASS="container">
    <div class="row">

        <div class="col-sm-3" style="border-right:2px solid black">
            @if($protien->img === 'fakeNull.jpg' || $protien->img === '')
                <div>
                   <br><br>
                    <img class="img-fluid" src="{{url('bgProtien.jpg')}}">
                </div>
            @else
                <div>
                    <img src="{{url('uploaded')}}/{{$protien->img}}" class="img-fluid" >
                </div>
            @endif
                <br>
        </div>


        <div class="col-sm-8">
            @foreach($protien->comments as $one)
                @if($one->accept == 1)
                <div>
                    <p class="lead text-capitalize font-weight-bold">
                        <mark>{{$one->custmor}}</mark>
                        Says: {{$one->body}}
                </div>
                @endif
            @endforeach

            <form style="opacity:.7" method="post" action="{{url('comment/'.$protien->id)}}" class="form-group">
                {{csrf_field()}}
                <input name="company_id" type="hidden" value="{{$protien->company_id}}">
                <input class="form-control" type="hidden" placeholder="what is your name?" name='custmor'>
                <textarea class="form-control" placeholder="Say something...?" name="body"></textarea>
                <input name="submit" class="btn btn-success" type="submit" value="Add comment">
            </form>

        </div>
    </div>
    <hr>


</div>

@if($errors->has('comment'))
    <script >
        alert('you can not make another comment');
    </script>
@endif


@stop
