<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" integrity="sha384-WskhaSGFgHYWDcbwN70/dfYBj47jz9qbsMId/iRN3ewGhXQFZCSftd1LZCfmhktB" crossorigin="anonymous">
</head>

@php
    if(Auth::check() and Auth::User()->img != "" ){
        $xx=explode("|",Auth::User()->img);
    }
@endphp



<body style="background-color:silver">
<br>
<br>
<nav class="navbar navbar-expand-md navbar-dark bg-dark fixed-top">

    @if(Auth::check() && Auth::user()->name == 'amro')
        <a class="navbar-brand" href="{{url('user')}}/{{ Auth::user()->name }}">
            <img src="{{url('sperm.jpg')}}"  style="height:40px;width:40px;border-radius:50%"> أهلا بالسموحة
        </a>
        <a class="navbar-brand" href="{{route('protien.index')}}"> Supplemnts</a>
        <a class="navbar-brand" href="{{url('signout')}}">SignOut</a>   ;


    @elseif(Auth::check() && Auth::user()->email == 'abusaqer911@hotmail.com')
      @if(Request::segment(1) != 'user')
        <a class="navbar-brand" href="{{url('user')}}/{{ Auth::user()->name }}">
            @if(Auth::user()->img != '' )
                <img style="height:40px;width:40px;border-radius:50%" src="{{url('/uploaded')}}/{{end($xx)}}">
            @else
                <span style="color:orange; text-transform:capitalize">{{ Auth::user()->name }}</span>
            @endif
        </a>
      @endif

        @php
           function is_id($id){
            return is_numeric($id)?true:false;
           }
        @endphp

            {{-- how to show supplemtns on create page and hide create too on same page --}}
        @if(Request::segment(2)  === 'create')
            <a class="navbar-brand" href="{{url('/protien')}}">
                {{trans('lang.supplemtns')}}
            </a>
        @endif

        @if(Request::segment(1) == 'ahmad' || Request::segment(2) == 'starz' )
              <a class="navbar-brand" href="starz/create"> NewStarz</a>
        @endif

        @if(Request::segment(2) !== 'create')
            <a class="navbar-brand" href="{{url('/protien/create')}}">
                {{trans('lang.NewProtien')}}
            </a>
        @endif

            {{-- how to show supplemnts page on show and edit page --}}
        @if(is_id(Request::segment(2)) || Request::segment(1) != 'protien')
            <a class="navbar-brand" href="{{url('/protien')}}">
                {{trans('lang.supplemtns')}}
            </a>
        @endif


        <a class="navbar-brand" href="{{url('/mycv2')}}">
            {{trans('lang.resume')}}
        </a>

        <a class="navbar-brand" href="{{url('ahmad/starz')}}">
            {{trans('lang.starz')}}
        </a>

        @php
            $coms= \App\Comment::where('accept',0)->count();
        @endphp


        <a class="navbar-brand" href="{{url('settings')}}">
            {{trans('lang.settings')}}
            @if($coms >0)
                <span class="navbar-brand badge" style="background-color: #fd7e14 ">
            {{$coms}}
            </span>
            @endif
        </a>

          <form class="navbar-brand " action="{{url('lang')}}" method="post">
              {{csrf_field()}}
              <select name="lang" id="">
                  <option selected >اختر لغتك ال</option>
                  <option value="arabic">العربية</option>
                  <option value="english">English</option>
              </select>
              <input type="submit" name="submit">
          </form>





        <a class="navbar-brand" href="{{url('signout')}}">SignOut</a>


    @elseif(Auth::check())
        @if(Request::segment(1) != 'user')
            <a class="navbar-brand" href="{{url('user')}}/{{ Auth::user()->name }}">
                @if(Auth::user()->img != '' )
                    <img style="height:40px;width:40px;border-radius:50%" src="{{url('/uploaded')}}/{{end($xx)}}">
                @else
                    <span style="color:orange; text-transform:capitalize">{{ Auth::user()->name }}</span>
                @endif
            </a>
        @endif


        <a class="navbar-brand" href="{{url('protien')}}"> Supplemnts</a>
        <a class="navbar-brand" href="{{url('signout')}}">SignOut</a>


    @else
        <a style="color: #fd7e14" class="x navbar-brand" href="../login"> Login </a>
        <a style="color: #fd7e14" class="x navbar-brand" href="../register"> Register</a>
    @endif
</nav>
<br>

<div class="container">
    @yield('mesg')
</div>


<br><br><br><br>

@php

@endphp

<div style="background-color:orange;
            width:100%;height:30px;
            font-weight: bolder; font-size: 20px;
            position: fixed; bottom:0">
    <center>
        Quick Picks Convenience Store - Mission Bay
    </center>
</div>

<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>

</body>
</html>
