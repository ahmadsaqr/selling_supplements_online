@extends('protien.master')
@section('mesg')

<div class='container'>
   
<h3>Best People Are Here</h3><br><br>
     <!-- <h6><a href="{{ route('starz.create') }}"> Add-New-Starz</a></h6>  -->
    <!-- <h6><a href="{{ url('ahmad/starz/create') }}"> Add-New-Starz</a></h6> -->
    <!-- <h6><a href="starz/create"> Add-New-Starz</a></h6> -->




<form method="POST" action="{{url('ahmad/starz')}}" >
<table class="table">
    <tr style="font-size: x-large;font-weight: bolder; color: #fd7e14">
        <td class="font-weight-bold text-capitalize">name</td>
        <td class="font-weight-bold text-capitalize">position</td>
        <td class="font-weight-bold text-capitalize">mobile</td>
        <td class="font-weight-bold text-capitalize">edit</td>
        <td class="font-weight-bold text-capitalize">

            @php
              $x=\app\Starz::all();
            @endphp

            @if(! count($x) == 0 )
                <input class="btn btn-danger " type="submit"php  value="Fired" >
            @endif
        </td>
    </tr>


@foreach($all as $one)
    <tr style="font-size: larger;font-weight: bolder; color: #fd7e14">
        <td>
            <a href="starz/{{$one->id}}">
                {{$one->name}}
            </a>
        </td>

        <td>{{$one->position}}</td>
        <td>+64{{$one->mobile}}</td>

        <td>
            <a  href="starz/{{$one->id}}/edit">Edit Info </a>
        </td>

        <td>
                {{csrf_field()}}
                <input type="hidden" value="DELETE" name="_method">
                <input type="checkbox" value="{{$one->id}}" name="del[]">
        </td>

    </tr>
@endforeach

</table>
</form>

{{$all->render()}}



</div>
@endsection()
