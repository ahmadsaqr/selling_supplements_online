@extends('protien.master')
@section('mesg')

    {{----}}
    <h3 class="text-center">Edit Starz Info </h3>
        <form method="post" class="form-group" action="{{url('ahmad/starz')}}/{{$starz->id}}">
            {{csrf_field()}}
        <input type="hidden" name="_method" value="PUT">
        <input class='form-control' type="text" value="{{$starz->name}}" name="name" placeholder="new Strarz Name">
        <input class="form-control" type="text" value="{{$starz->position}}" name="position" placeholder="new Strarz postion">
        <input class="form-control" type="text" value="{{$starz->mobile}}" name="mobile" placeholder="new Strarz Mobile">
        <input class="form-control btn btn-success" type="submit" value="update your Starz">

    </form>

    <div class="container"  style="background-image:url('/../mm.jpg') ">
        @foreach($errors->all() as $error)
            <div  class="font-weight-bold" style="color: #5a6268; font-size: large">{{ $error }}</div>
        @endforeach
    </div>
</div>
@endsection()