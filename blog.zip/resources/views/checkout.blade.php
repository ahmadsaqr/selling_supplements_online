@extends('protien.master')
@section('style')
    <style>

        body{
            background: beige;
        }

        .StripeElement {
            box-sizing: border-box;

            height: 40px;

            padding: 10px 12px;

            border: 1px solid transparent;
            border-radius: 4px;
            background-color: white;

            box-shadow: 0 1px 3px 0 #e6ebf1;
            -webkit-transition: box-shadow 150ms ease;
            transition: box-shadow 150ms ease;
        }

        .StripeElement--focus {
            box-shadow: 0 1px 3px 0 #cfd7df;
        }

        .StripeElement--invalid {
            border-color: #fa755a;
        }

        .StripeElement--webkit-autofill {
            background-color: #fefde5 !important;
        }
    </style>
@endsection
@section('mesg')
        
        <br>
        @if($cart->items)
        <div class="container">
            <div class="row">
                <div class="col-md-8" style="border-right: 5px orange solid ">
                    
            <table class="table table-responsive container table-stripped">
            <tr>
                <td>Item</td>
                <td>Price</td>
                <td>Quntity</td>
                <td>Sub-Totoal</td>
                <td>Image</td>
                <td>Edit</td>
                <td>Remove</td>
            </tr>            
             <tr>   
         
            @foreach($cart->items as $one )
                <td>{{ $one['type']  }} <br> -  {{ $one['company'] }}  </td>
                <td>$ {{ $one['price']  }}</td>
                <td>{{ $one['quntity']  }}</td>
                <td class="">$ {{ $one['price'] * $one['quntity']  }}  </td>
                <td><img style="max-height: 30px; max-width: 30px;" 
                         src="../uploaded/{{ $one['img']  }}"></td>
                
                <td>
                    <form action='checkOutEdit/{{$one["protien_id"]}}' method="post">
                         @csrf
                        <input style="width: 25px" type="text" name="quntity" value="{{ $one['quntity'] }}">
                        <input style="width: 55px; padding: 0px !important" type="submit" value="update" class="btn btn-info">                  
                    </form>
                </td>

                <td>
                    <form method="post" action="checkOutDelete/{{$one['protien_id']}} ">
                        @csrf
                        <input style="width: 55px; padding: 0px !important" 
                               class="btn btn-danger" type="submit" name="remove" value='remove'> 
                    </form>
                </td>
            </tr>
            @endforeach
            <td></td>
            <td></td>
            <td style="text-decoration: underline;"> {{ $cart->tq }}</td>
            <td style="text-decoration: underline;">${{ $cart->tp }}</td>
            <td></td>
            <td></td>
        </table>
        </div>
        

        <div style="width: 70%" class="col-md-4">
                    <form action='payment' method="post"  id="payment-form">
                        @csrf
                        <input type="hidden" name="amount" value="{{ session()->get('cart')->tp  }}">
                        <div class=''>
                            <label for="card-element">
                               <h4 class="container" >Credit or debit card</h4> 
                            </label>
                            <div id="card-element">
                                <!-- A Stripe Element will be inserted here. -->
                            </div>

                            <!-- Used to display form errors. -->
                            <div id="card-errors" role="alert"></div>
                        </div>

                        <button class="btn btn-info">Submit Payment</button>
                    </form>
                </div>
            </div>
        </div>
        


            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            
        

@endif    

@endsection




@section('script')

    <script src="https://js.stripe.com/v3/"></script>

    
    <script>

    window.onload=function () {


        var stripe = Stripe('pk_test_b40R2pYLVo5EbNr8ZgKOOQmn00DAIEQQQx');

// Create an instance of Elements.
        var elements = stripe.elements();

// Custom styling can be passed to options when creating an Element.
// (Note that this demo uses a wider set of styles than the guide below.)
        var style = {
            base: {
                color: '#32325d',
                fontFamily: '"Helvetica Neue", Helvetica, sans-serif',
                fontSmoothing: 'antialiased',
                fontSize: '16px',
                '::placeholder': {
                    color: '#aab7c4'
                }
            },
            invalid: {
                color: '#fa755a',
                iconColor: '#fa755a'
            }
        };

// Create an instance of the card Element.
        var card = elements.create('card', {style: style});

// Add an instance of the card Element into the `card-element` <div>.
        card.mount('#card-element');

// Handle real-time validation errors from the card Element.
        card.addEventListener('change', function (event) {
            var displayError = document.getElementById('card-errors');
            if (event.error) {
                displayError.textContent = event.error.message;
            } else {
                displayError.textContent = '';
            }
        });

// Handle form submission.
        var form = document.getElementById('payment-form');
        form.addEventListener('submit', function (event) {
            event.preventDefault();

            stripe.createToken(card).then(function (result) {
                if (result.error) {
                    // Inform the user if there was an error.
                    var errorElement = document.getElementById('card-errors');
                    errorElement.textContent = result.error.message;
                } else {
                    // Send the token to your server.
                    stripeTokenHandler(result.token);
                }
            });
        });

// Submit the form with the token ID.
        function stripeTokenHandler(token) {
            // Insert the token ID into the form so it gets submitted to the server
            var form = document.getElementById('payment-form');
            var hiddenInput = document.createElement('input');
            hiddenInput.setAttribute('type', 'hidden');
            hiddenInput.setAttribute('name', 'stripeToken');
            hiddenInput.setAttribute('value', token.id);
            form.appendChild(hiddenInput);

            // Submit the form
            form.submit();

        }

        }
    </script>

@endsection

