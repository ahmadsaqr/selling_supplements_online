@extends('protien.master')

@section('head')
    <style>
        body{background: black;
            color:white;
            font-weight: bolder;
            font-size: 21px}
    </style>
@endsection

@section('mesg')

<style>
    .div1{
        height: 200px;
        width: 200px;
        background-color: orange;
        margin:250px auto ;
    }

    #x{
        height: 70px;
        width: 70px;
        background-color: orange;
        top:50px;
        right:50px;
        position: fixed;
    }

    #x span{
        position:absolute;
        top:0;
        right:0;
        font-weight: bold;
        font-size: 30px;
        z-index:999;
    }

    .mm{
        color:blue;
        font-size: 2em;
    }

</style>

<div id="x" class="scroll">
    <span>
    </span>
</div>

<br><br><br>


<h1 id="heading">heading...!</h1>

<button id="butt"> add new</button>

<ul id="ul">
    <li>ahmad</li>
    <li>fadi</li>
    <li>yousef</li>
</ul>


<div id="div1" class="div1">div1</div>
<div id="div2" class="div1">div2</div>
<div id="div3" class="div1">div3</div>
<div id="div4" class="div1">div4</div>



@section('script')


@endsection
@endsection


