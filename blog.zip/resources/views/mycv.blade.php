
@extends('protien.master')

@section('head')
    <style>
        body{background: black;
            color:white;
            font-weight: bolder;
            font-size: 21px}

        li{text-align: left}

        H2{text-decoration: underline}

        ol li ol li{list-style-type:disc}

        li,ol{text-transform:lowercase}

    </style>
@endsection




@section('mesg')
    <a href="{{url('javascript#div2')}}">
        div3
    </a>

<div class="container">
    <div class="row">

        <div class="col-xl-6 table-bordered" style="text-align: center">
            <h2> FRONT END </h2>
            <ol>
                <li>HTML5 </li>
                <li>CSS3
                    <ol>
                        <li>MATERLIZE</li>
                        <li>FONT AWESOME</li>
                        <li>SASS</li>
                    </ol>
                </li>
                <li>BOOTSTRAP 3 & 4 </li>
                <li>JAVESCRIPT
                    <ol>
                        <li>jQurey</li>
                        <li>NODE JS</li>
                        <li>jason</li>
                    </ol>
                </li>
            </ol>
        </div>

        <div class="col-xl-6 table-bordered" style="text-align: center">
            <h2>BACK END </h2>
            <ol>
                <li>MYSQL</li>
                <li>PHP
                    <ol>
                        <li>Array functions !</li>
                        <li>superGlobal Variables !</li>
                        <li>regular Expression</li>
                        <li>LARAVEL
                            <ol>
                                <li>packages !!</li>
                            </ol>
                        </li>
                        <li>AJAX</li>
                        <li>SECURITY
                            <ol>
                                <li>AWARNESS/knowledge</li>
                                <li>PROTECTION</li>
                                <li>cross site script</li>
                            </ol>
                        </li>
                        <li>WORD PRESS</li>
                    </ol>
                </li>
                <li>VUE</li>
                <li>REACT</li>

            </ol>
        </div>
    </div>
</div>


@endsection
