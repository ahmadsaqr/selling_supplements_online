@extends('protien.master')

@section('mesg')

    <h1 style="margin:250px 400px ">
        the page is not found .....!
    </h1>

@stop()
