@extends('protien.master')
@section('head')
    <style>
    body{background:#ffeeba; color:white;font-weight: bolder;}
    </style>
@stop
@section('mesg')

    @php

        function  test($one){

                    $all_com=\App\Company::all();

                    foreach ($all_com as $com){
                    $all[]=$com->name.'.'.$com->img;
                    }

                   

                   $a='C:\\Users\\ahmad\\Desktop\\laptop\\starzBlog\\public\\';
                   $b='realPath';
                   $string= $a.$one.$b;


                   $files = File::files(public_path());

                   for ($x=0; $x<count($files); $x++){
                       $paths[]= $files[$x].'realPath';
                   }

                   $r=null;
                   if(in_array($string,$paths)){
                         $r=$one;
                   }
                   else{
                        $r='com.png';
                   }
                   return $r;
               }

    @endphp

    <div class="container">
        <div class="row">

                @php
                    $all_com=\App\Company::all();
                        foreach($all_com as $com){
                           $xx[]=$com->name.'.'.$com->img;
                           $names[]=$com->name;
                        }

                foreach($xx as $key=>$x){

                        if($names[$key] ==='ronniecoleman'){
                            echo '<a href=http://www.'. $names[$key].'.net>';
                            echo "<img style='width:350px;height:400px' src =" . test($x) . ">";
                            echo '</a>';
                        }
                        else{
                            echo '<a href=http://www.'. $names[$key].'.com>';
                            echo "<img style='width:350px;height:400px' src =" . test($x) . ">";
                            echo '</a>';
                        }
                }
                @endphp

        </div>
    </div>

@endsection 

