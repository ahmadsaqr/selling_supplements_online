<?php

namespace App\Http\Requests;

use Illuminate\Support\Facades\Auth;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Request;

use App\Http\Requests\Route;

class shortCutData extends FormRequest
{

    public function authorize()
    {
        return true;
    }


    public function rules(Request $request)
    {
        if ($request->path()=== 'register'){
           return    $data = [
                    'name' => '|required',
                    'email' => 'required|unique:users|email',
                    'password' => 'required'
                ];
        }


        else{

            $uri = $request->path();
            $user_id =Auth::user()->id;
            $id=$request->protien;


            if($uri === "user/".$user_id  ){
              return  $data = [
                    'oldpassword' => 'required',
                    'newpassword1' => 'required',
                    'newpassword2' => 'required'
                ];
            }


            if($uri ===  "protien" and $request->isMethod('post')){
                return  $data = [
                    'price' => 'required|numeric|max:200|min:20',
                    'company_id' => 'required',
                    'type' => 'required',
                    'img' => 'image|mimes:jpg,jpeg,png'
                ];
            }


            if($uri ===  "protien/".$id ){
                return  $data = [
                    'price' => 'required|numeric|max:200|min:20',
                ];
            }
        }

    }


    public function messages()
    {
        return [
            'name.required' => 'Please Type the Your Name',
        ];
    }

}

