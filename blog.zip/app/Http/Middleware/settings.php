<?php

namespace App\Http\Middleware;

use Closure;
use App\User;
use Illuminate\Support\Facades\Auth;

class settings
{
    public function handle($request, Closure $next)
    {
          if(auth()->check()){

              if( Auth::user()->admin===1) {
                  return $next($request);
              }

              else{
                  Auth::logout();
                  return redirect(url('login'))->withErrors([
                      'mesg1' => 'What are you doing mate ?!']);
              }
          }


          else{
              return redirect(url('login'))->withErrors([
                  'mesg2' => 'YOU NOT AUTHORISED',
              ]);

          }

    }
}
