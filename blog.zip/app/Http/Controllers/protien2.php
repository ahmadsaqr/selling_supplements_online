<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class protien2 extends Controller
{
    public function update($id, Request $request){

        if($request->img){
            $request->validate(['img' => 'required|image|mimes:jpg,jpeg,png']);
            $img=time().$request->img->getClientOriginalName();

            $p=\App\Protien::find($id);
                $p->img=$img;
            $p->save();

            $request->img->move(public_path('uploaded'), $img);
            return redirect(url('protien'));
        }
        else{
            return redirect()->back();
        }
    }
}






