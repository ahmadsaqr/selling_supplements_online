<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Company;
use App\Protien;
use App\Comment;
use Illuminate\Support\Facades\DB;

class settings extends Controller
{
    public function create_company(){
        $com =Company::all();
        return view('settings',compact('com'));
    }


    public function store_company(Request $request){
        //validate
        if($request->name !== null ){

            // to make the new company unique
            $request->validate(['name' => 'required|unique:companies']);

            //in case not upload picture
            if ($request['img']== ''){
                $request['img']= 'jpg';
            }

            //store
            $com=new Company;
                $com->name=$request->name;
                $com->img =$request->img;
            $com->save();

            //redirect
            return redirect(url('settings'));
        }
        else{
          return back();
        }

    }


    public function destroy_company(Request $request){

//            dd($request->all());  ===> strange  because only reyurn an ID (number)

        if($request->company != ''){
             Company::find($request->company)->delete();
             Protien::where('company_id',$request->company)->delete();
             Comment::where('company_id',$request->company)->delete();
             return redirect('/settings');
          }

          else{
              return redirect('/settings')->withErrors([
                  'mesg' => 'ther is no such company to delete it']);
          }
    }


    public function acceptcomment(Request $request){

//        dd($request->url());   "http://127.0.0.1:8000/acceptcomment"
//        dd($request->fullUrl());  "http://127.0.0.1:8000/acceptcomment"
//        dd($request->path()) ;
//        dd($request->method());

        $commentid=$request['commentid'];
        $protienid=$request['protienid'];

        \App\Comment::find($commentid)->update([ 'accept' => 1]);

        return redirect(url('protien/'.$protienid));
}

    public function deletecomment(Request $request){

        $commentid=$request['commentid'];
        Comment::find($commentid)->delete();

//      to delete the User => User Tabl  \App\User::where('name',$username)->delete();

        return redirect(url('settings'));
    }

    public function editcomment(Request $request){


//        $data= $request->only(['commentid', 'protienid']) ;

        if($request['commentbody'] != ''){
            \App\Comment::find($request['commentid'])->update([
                'accept' => 1,
                'body' => $request['commentbody'] ]);

            return redirect(url('protien/'. $request['protienid']));
        }

        else{
            $commentbody = '********';
            \App\Comment::find($request['commentid'])->update([
                'accept' => 1,
                'body' => $commentbody ]);

            return redirect(url('protien/'.$request['protienid']));
        }

    }

}


