<?php

namespace App;


class Cart{

    public $items=[];
    public $tq=0;
    public $tp=0;


    public function __construct($cart=null)
    {
      if($cart){
          $this->items=$cart->items;
          $this->tq=$cart->tq;
          $this->tp=$cart->tp;
      }
      else{
          $this->items=[];
          $this->tq=0;
          $this->tp=0;
      }
    }



    public function add($protien){
        $item=[
            'protien_id'     => $protien->id,
            'type'           => $protien->type,
            'price'          => $protien->price,
            'quntity'        => 0,
            'img'            => $protien->img,
            'company'        => $protien->company->name,
        ];

        if(! array_key_exists($protien->id ,$this->items)){
            $this->items[$protien->id]=$item;
            $this->tq +=1;
            $this->tp +=$protien->price;
        }
        else{
            $this->tq +=1;
            $this->tp +=$protien->price;
        }

        $this->items[$protien->id]['quntity'] +=1;
    }



    public function delete($protien){

        if(array_key_exists($protien->id ,$this->items)){

            $this->tq -=$this->items[$protien->id]['quntity'];
            $this->tp -=$protien->price * $this->items[$protien->id]['quntity'];
            unset($this->items[$protien->id]);  
        }   
      
      }
 

      public function edit($protien, $newQuntity){
            $this->tq -=$this->items[$protien->id]['quntity'];
            $this->tp -=$protien->price * $this->items[$protien->id]['quntity'];

            $this->items[$protien->id]['quntity']=$newQuntity;

            $this->tq +=$newQuntity;
            $this->tp +=$protien->price * $newQuntity;

        
      }

  }


